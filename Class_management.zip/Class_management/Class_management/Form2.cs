﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Class_management
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

            var ds = DB.Class1.GetDataTable($"select E.compellation,R.school_year,R.grade,R.status,R.school,R.register from Registration_status R join EssentialInformation E on R.id=E.id ");
            //dataGridView1.DataSource = ds.Tables[0];
            dataGridView1.DataSource = ds;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            var ds = DB.Class1.GetDataTable($"select E.compellation,R.school_year,R.grade,R.status,R.school,R.register from Registration_status R join EssentialInformation E on R.id=E.id  where E.compellation like '%{textBox1.Text}%'");
            //dataGridView1.DataSource = ds.Tables[0];
            dataGridView1.DataSource = ds;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form22 form22 = new Form22();
            form22.ShowDialog();
        }
    }
}
