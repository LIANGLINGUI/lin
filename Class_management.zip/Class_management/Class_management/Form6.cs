﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Class_management
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        private void Form6_Load(object sender, EventArgs e)
        {
            dataGridView1.AutoGenerateColumns = false;
            var ds = DB.Class1.GetDataTable($"select E.compellation,c.date,c.shangke,c.xiake,c.kechengming,c.renkelaoshi from EssentialInformation E join curriculum c on E.id=c.id ");
            dataGridView1.DataSource = ds;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dataGridView1.AutoGenerateColumns = false;
            var ds = DB.Class1.GetDataTable($"select E.compellation,c.date,c.shangke,c.xiake,c.kechengming,c.renkelaoshi from EssentialInformation E join curriculum c on E.id=c.id where E.compellation like '%{textBox1.Text}%'");
            dataGridView1.DataSource = ds;
        }
    }
}
