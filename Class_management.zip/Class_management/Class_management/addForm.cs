﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DB;

namespace Class_management
{
    public partial class addForm : Form
    {
        public addForm()
        {
            InitializeComponent();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        
        
        private void button1_Click(object sender, EventArgs e)
        {
            Class1.ConnectionString= "server=.;database=student_management;Integrated Security=True";
            var delu = $"select account,password from manage where account='{textBox1.Text}'and [password]='{textBox2.Text}'";
            SqlConnection connection = new SqlConnection(Class1.ConnectionString);
            SqlCommand command = new SqlCommand(delu, connection);
            connection.Open();
            SqlDataReader reader = command.ExecuteReader();
            if (reader.Read())
            {
                MessageBox.Show("登录成功！");
                Form1 control = new Form1();
                control.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("登录失败！");
            }
            

        }
    }
}
