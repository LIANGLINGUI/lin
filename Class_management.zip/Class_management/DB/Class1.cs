﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DB
{
    public class Class1
    {
        /// <summary>
        /// 连接字符串
        /// </summary>
        public static string ConnectionString;
        /// <summary>
        /// 保存已建立的连接
        /// </summary>
        private static SqlConnection conn;
        /// <summary>
        /// 初始化到数据库的连接
        /// </summary>
        public static void InitConnection()
        {
            //只有当连接为空，或连接的状态不为“已打开”时，才重新初始化连接
            if (conn == null || conn.State != System.Data.ConnectionState.Open)
            {
                conn = new SqlConnection(ConnectionString);
                conn.Open();
            }
        }
        /// <summary>
        /// 获取一个DataReader（读取器），是非断开式查询
        /// </summary>
        /// <param name="sql"></param>
        /// <returns></returns>
        public static SqlDataReader GetDataReader(string sql)
        {
            InitConnection();
            //创建了一个SqlCommand的对象
            var cmd = new SqlCommand(sql, conn);
            return cmd.ExecuteReader();
        }
        /// <summary>
        /// 获取DataTable（数据表），是断开式的查询
        /// </summary>
        /// <param name="sql"></param>
        /// <returns></returns>
        public static DataTable GetDataTable(string sql)
        {
            InitConnection();
            //创建一个DataAdapter对象，用来将数据从数据库中全部读取到内存
            var adapter = new SqlDataAdapter(sql, conn);
            //创建一个内存中的“数据库”，用来保存从数据库中提取到的数据
            var ds = new DataSet();
            //调用Fill方法，完成数据的提取和填充工作
            adapter.Fill(ds);
            //将提取的数据表返回
            return ds.Tables[0];
        }
        /// <summary>
        /// 执行非Select的SQL语句
        /// </summary>
        /// <param name="sql"></param>
        /// <returns></returns>
        public static int ExecuteNonQuery(string sql)
        {
            InitConnection();
            //创建SQLCommand对象
            var cmd = new SqlCommand(sql, conn);
            //执行SQL语句并返回受影响的行数
            return cmd.ExecuteNonQuery();
        }
        /// <summary>
        /// 执行Sql语句，返回首行首列的结果
        /// </summary>
        /// <param name="sql"></param>
        /// <returns></returns>
        public static object ExecuteScalar(string sql)
        {
            InitConnection();
            var cmd = new SqlCommand(sql, conn);
            return cmd.ExecuteScalar();
        }
    }
}
