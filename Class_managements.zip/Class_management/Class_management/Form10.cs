﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Class_management
{
    public partial class Form10 : Form
    {
        public Form10()
        {
            InitializeComponent();
        }

        private void Form10_Load(object sender, EventArgs e)
        {
            dataGridView2.AutoGenerateColumns = false;
            var dss = DB.Class1.GetDataTable($"select * from classs");
            dataGridView2.DataSource = dss;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var sql = $"insert into classs([m id],class_name,[class size],name,[class features],one,two,tree) " +
                $"values('{textBox1.Text}','{textBox2.Text}','{textBox3.Text}','{textBox4.Text}','{textBox5.Text}','{checkBox1.Text}','{checkBox2.Text}','{checkBox3.Text}')";
            var row = DB.Class1.ExecuteNonQuery(sql);
            MessageBox.Show($"成功添加{row}条信息");
            dataGridView2.AutoGenerateColumns = false;
            var dss = DB.Class1.GetDataTable($"select * from classs");
            dataGridView2.DataSource = dss;
        }

        private void button2_Click(object sender, EventArgs e)
        {

            Close();
            dataGridView2.AutoGenerateColumns = false;
            var dss = DB.Class1.GetDataTable($"select * from classs");
            dataGridView2.DataSource = dss;
        }
    }
}
