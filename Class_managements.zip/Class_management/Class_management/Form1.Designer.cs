﻿
namespace Class_management
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.基本信息ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.注册信息ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.家庭信息ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.考证信息ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.基本信息ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.课程安排ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.奖励惩罚信息ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.班级管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.班级简介ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.值日安排ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.班费管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.班会ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.基本信息ToolStripMenuItem,
            this.班级管理ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(970, 25);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // 基本信息ToolStripMenuItem
            // 
            this.基本信息ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.注册信息ToolStripMenuItem,
            this.家庭信息ToolStripMenuItem,
            this.考证信息ToolStripMenuItem,
            this.基本信息ToolStripMenuItem1,
            this.课程安排ToolStripMenuItem,
            this.奖励惩罚信息ToolStripMenuItem});
            this.基本信息ToolStripMenuItem.Name = "基本信息ToolStripMenuItem";
            this.基本信息ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.基本信息ToolStripMenuItem.Text = "学生管理";
            // 
            // 注册信息ToolStripMenuItem
            // 
            this.注册信息ToolStripMenuItem.Name = "注册信息ToolStripMenuItem";
            this.注册信息ToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.注册信息ToolStripMenuItem.Text = "注册信息";
            this.注册信息ToolStripMenuItem.Click += new System.EventHandler(this.注册信息ToolStripMenuItem_Click);
            // 
            // 家庭信息ToolStripMenuItem
            // 
            this.家庭信息ToolStripMenuItem.Name = "家庭信息ToolStripMenuItem";
            this.家庭信息ToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.家庭信息ToolStripMenuItem.Text = "家庭信息";
            this.家庭信息ToolStripMenuItem.Click += new System.EventHandler(this.家庭信息ToolStripMenuItem_Click);
            // 
            // 考证信息ToolStripMenuItem
            // 
            this.考证信息ToolStripMenuItem.Name = "考证信息ToolStripMenuItem";
            this.考证信息ToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.考证信息ToolStripMenuItem.Text = "考证信息";
            this.考证信息ToolStripMenuItem.Click += new System.EventHandler(this.考证信息ToolStripMenuItem_Click);
            // 
            // 基本信息ToolStripMenuItem1
            // 
            this.基本信息ToolStripMenuItem1.Name = "基本信息ToolStripMenuItem1";
            this.基本信息ToolStripMenuItem1.Size = new System.Drawing.Size(153, 22);
            this.基本信息ToolStripMenuItem1.Text = "基本信息";
            this.基本信息ToolStripMenuItem1.Click += new System.EventHandler(this.基本信息ToolStripMenuItem1_Click);
            // 
            // 课程安排ToolStripMenuItem
            // 
            this.课程安排ToolStripMenuItem.Name = "课程安排ToolStripMenuItem";
            this.课程安排ToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.课程安排ToolStripMenuItem.Text = "课程安排";
            this.课程安排ToolStripMenuItem.Click += new System.EventHandler(this.课程安排ToolStripMenuItem_Click);
            // 
            // 奖励惩罚信息ToolStripMenuItem
            // 
            this.奖励惩罚信息ToolStripMenuItem.Name = "奖励惩罚信息ToolStripMenuItem";
            this.奖励惩罚信息ToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.奖励惩罚信息ToolStripMenuItem.Text = "奖励/惩罚信息";
            this.奖励惩罚信息ToolStripMenuItem.Click += new System.EventHandler(this.奖励惩罚信息ToolStripMenuItem_Click);
            // 
            // 班级管理ToolStripMenuItem
            // 
            this.班级管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.班级简介ToolStripMenuItem,
            this.值日安排ToolStripMenuItem,
            this.班费管理ToolStripMenuItem,
            this.班会ToolStripMenuItem});
            this.班级管理ToolStripMenuItem.Name = "班级管理ToolStripMenuItem";
            this.班级管理ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.班级管理ToolStripMenuItem.Text = "班级管理";
            // 
            // 班级简介ToolStripMenuItem
            // 
            this.班级简介ToolStripMenuItem.Name = "班级简介ToolStripMenuItem";
            this.班级简介ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.班级简介ToolStripMenuItem.Text = "班级简介";
            this.班级简介ToolStripMenuItem.Click += new System.EventHandler(this.班级简介ToolStripMenuItem_Click);
            // 
            // 值日安排ToolStripMenuItem
            // 
            this.值日安排ToolStripMenuItem.Name = "值日安排ToolStripMenuItem";
            this.值日安排ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.值日安排ToolStripMenuItem.Text = "值日安排";
            this.值日安排ToolStripMenuItem.Click += new System.EventHandler(this.值日安排ToolStripMenuItem_Click);
            // 
            // 班费管理ToolStripMenuItem
            // 
            this.班费管理ToolStripMenuItem.Name = "班费管理ToolStripMenuItem";
            this.班费管理ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.班费管理ToolStripMenuItem.Text = "班费管理";
            this.班费管理ToolStripMenuItem.Click += new System.EventHandler(this.班费管理ToolStripMenuItem_Click);
            // 
            // 班会ToolStripMenuItem
            // 
            this.班会ToolStripMenuItem.Name = "班会ToolStripMenuItem";
            this.班会ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.班会ToolStripMenuItem.Text = "班会";
            this.班会ToolStripMenuItem.Click += new System.EventHandler(this.班会ToolStripMenuItem_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 458);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(970, 22);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(128, 17);
            this.toolStripStatusLabel1.Text = "欢迎使用班级管理系统";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(970, 480);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "班级管理系统";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 基本信息ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 注册信息ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 家庭信息ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 考证信息ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 基本信息ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 课程安排ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 奖励惩罚信息ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 班级管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 班级简介ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 值日安排ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 班费管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 班会ToolStripMenuItem;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
    }
}