﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Class_management
{
    public partial class Form13 : Form
    {
        public Form13()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
        
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var sqls = $"update  skk set time='{textBox4.Text}',huodo='{textBox5.Text}' where id='{textBox3.Text}'";
            var rows = DB.Class1.ExecuteNonQuery(sqls);
            MessageBox.Show($"成功更改{rows}条信息");
            dataGridView1.AutoGenerateColumns = false;
            var ds = DB.Class1.GetDataTable($"select * from money_time");
            dataGridView1.DataSource = ds;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var sql = $"insert into skk(time,huodo) values('{textBox1.Text}','{textBox2.Text}')";
            var rows = DB.Class1.ExecuteNonQuery(sql);
            MessageBox.Show($"成功添加{rows}条信息");
            dataGridView1.AutoGenerateColumns = false;
            var ds = DB.Class1.GetDataTable($"select * from skk");
            dataGridView1.DataSource = ds;
        }

        private void Form13_Load(object sender, EventArgs e)
        {
            dataGridView1.AutoGenerateColumns = false;
            var ds = DB.Class1.GetDataTable($"select * from skk");
            dataGridView1.DataSource = ds;
        }
    }
}
