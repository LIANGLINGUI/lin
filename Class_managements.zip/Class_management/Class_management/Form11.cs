﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Class_management
{
    public partial class Form11 : Form
    {
        public Form11()
        {
            InitializeComponent();
        }

        private void Form11_Load(object sender, EventArgs e)
        {
            dataGridView1.AutoGenerateColumns = false;
            var ds = DB.Class1.GetDataTable($"select E.compellation,E.id,j.id,j.time,j.fraction from EssentialInformation E join time j on E.id=j.id ");
            dataGridView1.DataSource = ds;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {

            var dgResult = MessageBox.Show("确定删除吗？", "提示", MessageBoxButtons.OKCancel);
            if (dgResult == DialogResult.OK)//用户点击了确定
            {
                //获取用户选中行的ID
                var id = dataGridView1.SelectedRows[0].Cells[0].Value;
                var sql = $"DELETE FROM EssentialInformation,time WHERE id={id}";
                var row = DB.Class1.ExecuteNonQuery(sql);
                MessageBox.Show($"成功删除{row}条信息");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var sql = $"update  EssentialInformation set compellation='{textBox2.Text}' where id='{textBox1.Text}'";
            var row = DB.Class1.ExecuteNonQuery(sql);
            var sqls = $"update  time set time='{textBox3.Text}',fraction='{textBox4.Text}' where id='{textBox1.Text}'";
            var rows = DB.Class1.ExecuteNonQuery(sqls);
            MessageBox.Show($"成功更改{row}条信息");
            dataGridView1.AutoGenerateColumns = false;
            var ds = DB.Class1.GetDataTable($"select E.compellation,j.time,j.fraction from EssentialInformation E join time j on E.id=j.id ");
            dataGridView1.DataSource = ds;
        }
    }
}
