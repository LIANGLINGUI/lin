﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Class_management
{
    public partial class Form9 : Form
    {
        public Form9()
        {
            InitializeComponent();
        }
        DataSet dss;
        private void Form9_Load(object sender, EventArgs e)
        {
            dataGridView1.AutoGenerateColumns = false;
            var dss = DB.Class1.GetDataTable($"select * from classs");
            dataGridView1.DataSource = dss;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("请输入班级代号");
                return;
            }
            else if (textBox2.Text == "")
            {
                MessageBox.Show("请输入班级名称");
                return;
            }
            else if (textBox3.Text == "")
            {
                MessageBox.Show("请输入班级总人数");
                return;
            }
            else if (textBox4.Text == "")
            {
                MessageBox.Show("请输入班主任名称");
                return;
            }

            var sql = $"update  classs set class_name='{textBox2.Text}',[class size]='{textBox3.Text}',name='{textBox4.Text}',[class features]='{textBox5.Text}',one='{checkBox1.Text}',two='{checkBox2.Text}',tree='{checkBox3.Text}',[m id]='{textBox1.Text}' where id='{textBox6.Text}'";
            var row = DB.Class1.ExecuteNonQuery(sql);
            MessageBox.Show($"成功更改{row}条信息");
            dataGridView1.AutoGenerateColumns = false;
            var dss = DB.Class1.GetDataTable($"select * from classs");
            dataGridView1.DataSource = dss;
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
            dataGridView1.AutoGenerateColumns = false;
            var dss = DB.Class1.GetDataTable($"select * from classs");
            dataGridView1.DataSource = dss;

        }
    }
}
